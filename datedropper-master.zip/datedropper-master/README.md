# datedropper
datedropper is a jQuery plugin that provides a quick and easy way to manage dates for input fields.


[Usage and Examples](http://bit.ly/17ab6dt)

### Supported Languages

LANGUAGE  | OPTION
--------- | ---------
Arabic    | { lang: 'ar' }
Chinese   | { lang: 'zh' }
Dansk	    | { lang: 'da' }
Deutsch   | { lang: 'de' }
Dutch     | { lang: 'nl' }
Español	  | { lang: 'es' }
English	  | (Default)
Finnish   | { lang: 'fi' }
Français  | { lang: 'fr' }
Greek	    | { lang: 'gr' }
Hungarian | { lang: 'hu' }
Italian   | { lang: 'it' }
Polish    | { lang: 'pl' }
Portuguese | { lang: 'pt' }
Russian    | { lang: 'ru' }
Slovenian  | { lang: 'si' }
Ukrainian  | { lang: 'uk' }
Turkish   | { lang: 'tr' }
